15-112 Term Project: 

This is a game of Sudoku. 
The user is able to play different levels of randomly generated boards with the help of various hints. 
Hints include: h1: singletons
               h2: obvious tuples
               h3: x-wing
The user is also able to have endless possible combination of boards at the same level with the help of board transformations. 
Transformations include: rotations
                         row swaps
                         row block swaps
Additionally, there is a special color mode which is similar to an arcade mode. 
Users can play using colors instead of numbers. 


To run: 
Run the sudokuMain.py file

Libraries / modules: 
from cmu_graphics import *

Shortcut commands: 
Note: after a change is made in settings, the load button must be pressed to load a new game according to those changed settings
